import requests
from bs4 import BeautifulSoup
import csv
import time

new_url=[]
new_des1=[]
product_urls = []
product_names = []
product_prices = []
ratings = []
num_reviews = []
descriptions = []
asins = []
product_descriptions = []
manufacturers = []


base_url = "https://www.amazon.in/s?k=bags&crid=2M096C61O4MLT&qid=1653308124&sprefix=ba%2Caps%2C283&ref=sr_pg_"


for page in range(1, 21):
    url = base_url + str(page)
    response = requests.get(url)
    if response.status_code == 200:
        product = BeautifulSoup(response.content, 'html.parser')

        product_url = product.find_all("a", class_="a-link-normal s-underline-text s-underline-link-text s-link-style a-text-normal")
        product_name = product.find_all("span", class_="a-size-medium a-color-base a-text-normal")
        product_price = product.find_all("span", class_="a-price-whole")
        rating = product.find_all("span", class_="a-icon-alt")
        num_review = product.find_all("span", class_="a-size-base s-underline-text")

        for url1 in product_url:
            product_urls.append("https://amazon.in"+url1.get('href'))

        for rating1 in rating:
            ratings.append(rating1.get_text())

        for rev in num_review:
            num_reviews.append(rev.get_text())

        for name in product_name:
            product_names.append(name.get_text())

        for pri in product_price:
            product_prices.append(pri.get_text())

        time.sleep(2)



for url in product_urls:
    response = requests.get(url)
    if response.status_code == 200:
        soup = BeautifulSoup(response.text, 'html.parser')

        description = soup.find_all("meta", {"name": "description"})
        asin = soup.find_all("span", class_="a-text-bold")
        product_description = soup.find_all("div", {"id": "productDescription"})
        manufacturer = soup.find_all('span', string="Manufacturer &rlm; : &lrm; ")

        for des1 in description:
            new_des1.append(des1.get("content"))
            descriptions.append(new_des1)

        for pro_des in product_description:
            product_descriptions.append(pro_des.select_one(selector="p span").get_text())


        for manu in manufacturer:
            manufacturers.append(manu.find_next('span').get_text())

        for asin1 in asin:
            asins.append(asin1.find_next("span").get_text(strip=True))
#




# data = {
#     "Product URL": product_urls,
#     "Product Name": product_names,
#     "Product Price": product_prices,
#     "Rating": ratings,
#     "Number of Reviews": num_reviews,
#     "Description": descriptions,
#     "ASIN": asins,
#     "Product Description": product_descriptions,
#     "Manufacturer": manufacturers
# }


with open("amazon_products.csv", "w", newline="", encoding="utf-8") as csvfile:
    csvwriter = csv.writer(csvfile)
    # Write header
    csvwriter.writerow(["Product URL", "Product Name", "Description","Product description", "Product Price", "Rating", "Number of Reviews", "ASIN", "Manufacturer"])
    # Write data rows
    for i in range(len(product_urls)):
        csvwriter.writerow([product_urls[i], product_names[i], descriptions[i],product_descriptions[i],product_prices[i], ratings[i], num_reviews[i],asins[i],manufacturers[i]])

